This is just a deafult save for those having a hard time getting passed the intro screen on Pokemon Moon.

White Male
Name: Red

Goes into the Users\SDMC\Nintendo 3DS\0.. \0.. \title\00040000\ Folder
